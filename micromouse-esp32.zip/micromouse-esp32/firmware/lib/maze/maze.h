// maze.h: portable maze logic for the micromouse (header only, no hardware calls).
// Runs unchanged on a PC (unit tests), in the mms simulator and on the ESP32.
// Wall map: one byte per cell, bit N=1, E=2, S=4, W=8 (see docs/notes, Maze Algorithms 3.7).
#pragma once
#include <stdint.h>

namespace mm {

constexpr int MAXN = 16;
enum Dir : uint8_t { N = 0, E = 1, S = 2, W = 3 };
constexpr int DX[4] = {0, 1, 0, -1};
constexpr int DY[4] = {1, 0, -1, 0};

struct Cell { int8_t x, y; };

class Maze {
public:
    explicit Maze(int w = 16, int h = 16) { reset(w, h); }

    void reset(int w, int h) {
        w_ = w; h_ = h;
        for (int x = 0; x < MAXN; x++)
            for (int y = 0; y < MAXN; y++) { walls_[x][y] = 0; dist_[x][y] = -1; }
        for (int x = 0; x < w_; x++) { walls_[x][0] |= 1 << S; walls_[x][h_ - 1] |= 1 << N; }
        for (int y = 0; y < h_; y++) { walls_[0][y] |= 1 << W; walls_[w_ - 1][y] |= 1 << E; }
    }

    int width() const { return w_; }
    int height() const { return h_; }
    bool inBounds(int x, int y) const { return x >= 0 && y >= 0 && x < w_ && y < h_; }
    bool wall(int x, int y, int d) const { return (walls_[x][y] >> d) & 1; }
    uint8_t wallBits(int x, int y) const { return walls_[x][y]; }

    // Store the wall on BOTH sides of the boundary.
    void addWall(int x, int y, int d) {
        walls_[x][y] |= (1 << d);
        int nx = x + DX[d], ny = y + DY[d];
        if (inBounds(nx, ny)) walls_[nx][ny] |= (1 << ((d + 2) & 3));
    }

    // Flood fill (BFS outward from the goal cells). Unknown walls count as open.
    void flood(const Cell* goals, int ngoals) {
        for (int x = 0; x < w_; x++)
            for (int y = 0; y < h_; y++) dist_[x][y] = -1;
        Cell q[MAXN * MAXN];
        int head = 0, tail = 0;
        for (int i = 0; i < ngoals; i++) {
            dist_[goals[i].x][goals[i].y] = 0;
            q[tail++] = goals[i];
        }
        while (head < tail) {
            Cell c = q[head++];
            for (int d = 0; d < 4; d++) {
                if (wall(c.x, c.y, d)) continue;
                int nx = c.x + DX[d], ny = c.y + DY[d];
                if (inBounds(nx, ny) && dist_[nx][ny] == -1) {
                    dist_[nx][ny] = dist_[c.x][c.y] + 1;
                    q[tail++] = Cell{(int8_t)nx, (int8_t)ny};
                }
            }
        }
    }

    int distance(int x, int y) const { return dist_[x][y]; }

    // Open neighbour with the smallest number (-1 if there is none).
    int bestDir(int x, int y) const {
        int best = -1, bestD = 1 << 30;
        for (int d = 0; d < 4; d++) {
            if (wall(x, y, d)) continue;
            int nx = x + DX[d], ny = y + DY[d];
            if (inBounds(nx, ny) && dist_[nx][ny] >= 0 && dist_[nx][ny] < bestD) {
                best = d; bestD = dist_[nx][ny];
            }
        }
        return best;
    }

private:
    int w_ = 16, h_ = 16;
    uint8_t walls_[MAXN][MAXN];
    int16_t dist_[MAXN][MAXN];
};

}  // namespace mm
