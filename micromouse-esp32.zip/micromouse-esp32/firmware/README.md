# Firmware

| Folder | What | Status |
|---|---|---|
| [`lib/maze/`](lib/maze/) | Portable maze logic: wall map, flood fill, best direction. No hardware calls. | Done, unit tested on a PC |
| `src/` | The ESP32 program (control loop, state machine) | Not started: needs the ESP32 |
| `lib/control/` | PID, feedforward, velocity profile | Planned (milestone M6, tested on a PC first) |

## Rule for this folder

Code that does not touch hardware goes in `lib/` and has a unit test in [`../tests`](../tests).
Only the thin "hardware layer" (motors, encoders, gyro, IR, timer) is ESP32-specific, so a change of chip later
means rewriting only that layer. See the architecture diagram in the main README.
